# Required to distribute different parts of this
# package as multiple distributables
try:
    import pkg_resources
    pkg_resources.declare_namespace(__name__)
except ImportError:
    from pkgutil import extend_path
    __path__ = extend_path(__path__, __name__)

__version__ = "4.3.0"
